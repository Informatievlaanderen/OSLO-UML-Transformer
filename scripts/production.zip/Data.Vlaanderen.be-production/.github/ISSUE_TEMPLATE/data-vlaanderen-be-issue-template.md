---
name: Data.Vlaanderen.be issue template
about: Issue template for Data.Vlaanderen.be

---

_Issues in deze repository dienen om technische (broken links, verkeerde mapping van termen op URI's...) of editoriale (typo's, fouten in de HTML weergave...) problemen aan te kaarten. Voor inhoudelijke en semantische issues verwijzen we naar de [OSLO-Discussion repository](https://github.com/Informatievlaanderen/OSLO-Discussion/issues)._

**Link waar het probleem zich voor doet:** https://data.vlaanderen.be/

**Omschrijving van het probleem:** 

**Omschrijving van een mogelijke oplossing:**
